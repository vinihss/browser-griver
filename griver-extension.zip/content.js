"use strict";(()=>{var d={recordCommand:"griver:record",recordEvent:"griver:record-event",execute:"griver:execute",executeResult:"griver:execute-result",pageCommand:"griver:page",pageResult:"griver:page-result",stateChanged:"griver:state",captureScreenshot:"griver:screenshot",overlayQuery:"griver:overlay-query",overlayCommand:"griver:overlay-command",overlayState:"griver:overlay-state"};var D=["data-testid","data-test-id","data-test","data-qa","data-cy"];function g(t){let e=[],n=new Set,r=(f,h)=>{if(!f)return;let b=f.trim();!b||n.has(b)||(n.add(b),e.push({selector:b,unique:z(b),strategy:h}))};for(let f of D){let h=t.getAttribute(f);h&&r(`[${f}="${m(h)}"]`,f)}let o=t.getAttribute("id");o&&!/^\d/.test(o)&&!o.includes(" ")&&r(`#${m(o)}`,"id");let i=t.getAttribute("name");i&&r(`[name="${m(i)}"]`,"name");let c=t.getAttribute("aria-label");c&&r(`[aria-label="${m(c)}"]`,"aria-label");let a=t.getAttribute("placeholder");a&&r(`${t.tagName.toLowerCase()}[placeholder="${m(a)}"]`,"placeholder");let s=F(t);s&&r(`${t.tagName.toLowerCase()}[aria-label="${m(s)}"]`,"label");let l=j(t);l.length&&r(`${t.tagName.toLowerCase()}.${l.map(m).join(".")}`,"class");let v=V(t);return v&&r(v,"path"),e}function E(t,e=60){let n=(t.textContent??"").replace(/\s+/g," ").trim();if(!(!n||n.length>e))return n}function j(t){return Array.from(t.classList).filter(e=>e.length>0&&!/^(css|sc|jsx|emotion|_[a-zA-Z])/.test(e)).filter(e=>!/[0-9a-f]{6,}/i.test(e)).slice(0,3)}function F(t){let e=t.getAttribute("id");if(e){let r=document.querySelector(`label[for="${m(e)}"]`);if(r?.textContent)return r.textContent.replace(/\s+/g," ").trim().slice(0,40)}let n=t.closest("label");if(n?.textContent)return n.textContent.replace(/\s+/g," ").trim().slice(0,40)}function V(t){let e=[],n=t;for(;n&&n.nodeType===Node.ELEMENT_NODE&&e.length<8;){let r=n.tagName.toLowerCase();if(n.id&&!/^\d/.test(n.id)){e.unshift(`#${m(n.id)}`);break}let o=n.parentElement;if(o){let i=Array.from(o.children).filter(c=>c.tagName===n.tagName);i.length>1&&(r+=`:nth-of-type(${i.indexOf(n)+1})`)}e.unshift(r),n=o}return e.length?e.join(" > "):void 0}function z(t){try{return document.querySelectorAll(t).length===1}catch{return!1}}function m(t){return t.replace(/["\\]/g,"\\$&")}var w=class{recording=!1;paused=!1;onEvent;pendingInputs=new Map;emittedValues=new WeakMap;listeners=[];get isRecording(){return this.recording&&!this.paused}start(e){if(this.recording)return;this.recording=!0,this.paused=!1,this.onEvent=e;let n=a=>{if(!this.isRecording)return;let s=a.target;if(!s||!(s instanceof Element)||!K(s))return;let l=g(s);l.length&&(this.flushPending(),e({kind:"click",url:location.href,selectors:l.map(v=>v.selector),text:E(s),ts:Date.now()}))},r=a=>{if(!this.isRecording)return;let s=a.target;if(s instanceof Element&&R(s)){if(s instanceof HTMLSelectElement){this.flushPending(),this.emitChange(s,e);return}this.cancelPending(s),this.emitChange(s,e)}},o=a=>{if(!this.isRecording)return;let s=a.target;s instanceof Element&&R(s)&&(s instanceof HTMLSelectElement||(this.cancelPending(s),this.pendingInputs.set(s,setTimeout(()=>{this.pendingInputs.delete(s),this.isRecording&&this.emitChange(s,e)},500))))},i=a=>{if(!this.isRecording||!["Enter","Escape","Tab"].includes(a.key))return;this.flushPending();let s=a.target,l=s instanceof Element?g(s).map(v=>v.selector):void 0;e({kind:"keydown",url:location.href,key:a.key,selectors:l,ts:Date.now()})},c=()=>{this.isRecording&&window.scrollY!==0&&e({kind:"scroll",url:location.href,ts:Date.now()})};document.addEventListener("click",n,!0),document.addEventListener("change",r,!0),document.addEventListener("input",o,!0),document.addEventListener("keydown",i,!0),window.addEventListener("scroll",c,{passive:!0}),this.listeners.push(()=>document.removeEventListener("click",n,!0),()=>document.removeEventListener("change",r,!0),()=>document.removeEventListener("input",o,!0),()=>document.removeEventListener("keydown",i,!0),()=>window.removeEventListener("scroll",c))}flushPending(){let e=this.onEvent;if(e)for(let[n,r]of[...this.pendingInputs])clearTimeout(r),this.pendingInputs.delete(n),this.emitChange(n,e)}cancelPending(e){let n=this.pendingInputs.get(e);n&&(clearTimeout(n),this.pendingInputs.delete(e))}pause(){this.paused=!0}resume(){this.paused=!1}stop(){let e=[];if(this.onEvent)for(let[r,o]of[...this.pendingInputs])clearTimeout(o),this.pendingInputs.delete(r),this.emitChange(r,i=>e.push(i));this.recording=!1,this.paused=!1,this.onEvent=void 0;for(let r of this.listeners)r();this.listeners.length=0;for(let r of this.pendingInputs.values())clearTimeout(r);return this.pendingInputs.clear(),e}emitChange(e,n){let r=g(e);if(!r.length)return;let i=e instanceof HTMLInputElement&&e.type==="password"?"{{secret}}":e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement?e.value:"";this.emittedValues.get(e)!==i&&(this.emittedValues.set(e,i),n({kind:e instanceof HTMLSelectElement?"select":"input",url:location.href,selectors:r.map(c=>c.selector),value:i,text:E(e),ts:Date.now()}))}};function K(t){let e=t.tagName;if(e==="A"||e==="BUTTON"||e==="SUMMARY"||e==="LABEL")return!0;if(e==="INPUT"){let n=t.type;return!["text","password","email","number","search","tel","url","date"].includes(n)}return!!(t.getAttribute("role")==="button"||t.hasAttribute("onclick"))}function R(t){return t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement?!0:t instanceof HTMLInputElement?!["checkbox","radio","file","button","submit","reset","image"].includes(t.type):!!(t instanceof HTMLElement&&t.isContentEditable)}var C={visible:!1,recording:!1,paused:!1,steps:0,events:[],recipe:void 0,confirmed:!1},y=class{host;shadow;state=C;async mount(){this.ensureHost();try{let n=await chrome.runtime.sendMessage({type:d.overlayQuery})??C;return this.render(n),n}catch{return C}}render(e){if(this.state=e,!e.visible){this.host?.remove(),this.host=void 0,this.shadow=void 0;return}this.ensureHost(),this.paint()}destroy(){this.host?.remove(),this.host=void 0,this.shadow=void 0}ensureHost(){if(this.host?.isConnected)return;let e=document.createElement("div");e.setAttribute("data-griver-overlay",""),e.style.cssText="all: initial; position: static;";let n=e.attachShadow({mode:"open"});n.appendChild(J()),n.appendChild(this.build()),(document.documentElement||document.body).appendChild(e),this.host=e,this.shadow=n}build(){let e=document.createElement("div");e.className="griver-root";let n=document.createElement("div");n.className="griver-bar",n.appendChild(this.iconButton("\u23FA","Record",()=>{this.state.recording?this.state.paused?this.send("resume"):this.send("pause"):this.send("start")})),n.appendChild(this.iconButton("\u23F8","Pause",()=>{this.send("pause")})),n.appendChild(this.iconButton("\u23F9","Stop",()=>{this.send("stop")}));let r=document.createElement("div");r.className="griver-spacer",n.appendChild(r),n.appendChild(this.textButton("Cancel",()=>{this.send("cancel")})),n.appendChild(this.textButton("Confirm",()=>{this.send("confirm")})),e.appendChild(n);let o=document.createElement("div");o.className="griver-panel";let i=document.createElement("div");i.className="griver-panel-head";let c=document.createElement("span");c.className="griver-panel-title",c.textContent="Steps",i.appendChild(c);let a=document.createElement("button");a.className="griver-icon-btn",a.textContent="\u270E",a.title="Editar",a.setAttribute("aria-label","Editar"),a.addEventListener("click",h=>{h.stopPropagation(),this.send("edit")}),i.appendChild(a),o.appendChild(i);let s=document.createElement("div");s.className="griver-steps",o.appendChild(s);let l=document.createElement("div");l.className="griver-panel-foot";let v=this.textButton("Cancel",()=>{this.send("cancel")}),f=this.textButton("Save",()=>{this.send("save")});return f.classList.add("griver-primary"),l.appendChild(v),l.appendChild(f),o.appendChild(l),e.appendChild(o),e}paint(){let e=this.shadow;if(!e)return;let n=e.querySelector(".griver-steps");if(n){n.textContent="";let o=this.state.recipe?this.state.recipe.steps.map(W):this.state.events.map(Y);if(!o.length){let i=document.createElement("div");i.className="griver-empty",i.textContent="Nenhum passo capturado ainda.",n.appendChild(i)}for(let i of o){let c=document.createElement("div");c.className="griver-step",c.textContent=i,n.appendChild(c)}}let r=e.querySelector(".griver-bar");if(r){let o=Array.from(r.querySelectorAll("button")),i=o[0],c=o[1],a=o[2];i&&(i.textContent=this.state.recording&&!this.state.paused?"\u23F8":"\u23FA",i.title=this.state.recording&&!this.state.paused?"Pause":"Record"),c&&(c.style.display="none"),a&&(a.style.display=this.state.recording?"":"none")}}iconButton(e,n,r){let o=document.createElement("button");return o.className="griver-icon-btn",o.textContent=e,o.title=n,o.setAttribute("aria-label",n),o.addEventListener("click",i=>{i.stopPropagation(),r()}),o}textButton(e,n){let r=document.createElement("button");return r.className="griver-btn",r.textContent=e,r.addEventListener("click",o=>{o.stopPropagation(),n()}),r}async send(e){try{await chrome.runtime.sendMessage({type:d.overlayCommand,action:e})}catch{}}};function W(t){let e=t.target?.selectors?.[0]??"";switch(t.type){case"navigate":return`navegar para ${t.url??""}`;case"click":return`clicar em ${e}`;case"fill":return`preencher ${e} = ${t.value??""}`;case"select":return`selecionar ${e} = ${t.value??""}`;case"press":return`pressionar ${t.key??""}`;case"wait":return"esperar";case"waitFor":return`aguardar ${e}`;case"extract":return`extrair ${e}`;case"assert":return`verificar ${e}`;default:return t.type}}function Y(t){let e=t.selectors?.[0]??"";switch(t.kind){case"click":return`clicar em ${e}`;case"input":case"change":return`preencher ${e} = ${t.value??""}`;case"select":return`selecionar ${e} = ${t.value??""}`;case"keydown":return`pressionar ${t.key??""}`;case"navigate":return`navegar para ${t.url??""}`;case"scroll":return"rolar a p\xE1gina";default:return t.kind}}function J(){let t=document.createElement("style");return t.textContent=`
    :host { all: initial; }
    .griver-root {
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      color: #e6e9ef;
    }
    .griver-bar {
      position: fixed;
      top: 12px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 8px;
      border: 1px solid #2b303a;
      border-radius: 10px;
      background: rgba(27, 30, 36, 0.96);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      pointer-events: auto;
    }
    .griver-spacer { width: 8px; }
    .griver-icon-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid #2b303a;
      border-radius: 6px;
      background: #22262e;
      color: #e6e9ef;
      font: inherit;
      font-size: 13px;
      line-height: 1;
      cursor: pointer;
    }
    .griver-icon-btn:hover { border-color: #6b8afd; }
    .griver-btn {
      padding: 5px 10px;
      border: 1px solid #2b303a;
      border-radius: 6px;
      background: #22262e;
      color: #e6e9ef;
      font: inherit;
      font-size: 12px;
      cursor: pointer;
    }
    .griver-btn:hover { border-color: #6b8afd; }
    .griver-primary { background: #6b8afd; border-color: #6b8afd; color: #0d1017; font-weight: 600; }
    .griver-panel {
      position: fixed;
      top: 12px;
      right: 12px;
      width: 260px;
      max-height: calc(100vh - 24px);
      display: flex;
      flex-direction: column;
      border: 1px solid #2b303a;
      border-radius: 10px;
      background: rgba(27, 30, 36, 0.97);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      overflow: hidden;
      pointer-events: auto;
    }
    .griver-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 10px;
      border-bottom: 1px solid #2b303a;
    }
    .griver-panel-title {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      color: #98a1b0;
    }
    .griver-steps {
      flex: 1;
      overflow-y: auto;
      padding: 6px;
      display: flex;
      flex-direction: column;
      gap: 4px;
      min-height: 60px;
    }
    .griver-step {
      padding: 5px 8px;
      border-radius: 6px;
      background: #22262e;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 11px;
      line-height: 1.45;
      word-break: break-word;
    }
    .griver-empty {
      padding: 10px;
      color: #98a1b0;
      font-size: 12px;
      text-align: center;
    }
    .griver-panel-foot {
      display: flex;
      justify-content: space-between;
      gap: 6px;
      padding: 8px 10px;
      border-top: 1px solid #2b303a;
    }
  `,t}var u=class extends Error{constructor(n,r){super(n);this.tried=r;this.name="PageError"}tried};function p(t,e={}){let n=e.requireMatch??!0,r=[];for(let o of t.selectors){r.push(o);let i;try{i=document.querySelector(o)??void 0}catch{i=void 0}if(i){if(t.nth!==void 0&&(i=document.querySelectorAll(o)[t.nth]??i),!n)return{element:i,tried:r};if(T(i))return{element:i,tried:r}}}if(t.text){r.push(`text="${t.text}"`);let o=X(t.text);if(o)return{element:o,tried:r}}throw new u(`nenhum seletor casou com o elemento (tentados: ${r.join(", ")})`,r)}function X(t){let e=document.createTreeWalker(document.body??document,NodeFilter.SHOW_ELEMENT),n=e.currentNode;for(;n;){if((n.textContent??"").trim()===t.trim()&&n.children.length===0)return n;n=e.nextNode()}}function T(t){if(!(t instanceof HTMLElement))return!0;let e=window.getComputedStyle(t);return e.display==="none"||e.visibility==="hidden"||e.opacity==="0"?!1:t.offsetParent!==null||t.getClientRects().length>0}function k(t,e={}){let{element:n}=p(t),r=e.clickCount??1;n instanceof HTMLElement&&n.scrollIntoView({block:"center",behavior:"instant"});let o=n.getBoundingClientRect(),i=o.left+o.width/2,c=o.top+o.height/2,a={bubbles:!0,cancelable:!0,composed:!0,view:window,clientX:i,clientY:c,button:0};for(let s=0;s<r;s++)n.dispatchEvent(new PointerEvent("pointerdown",a)),n.dispatchEvent(new MouseEvent("mousedown",a)),n instanceof HTMLElement&&n.focus(),n.dispatchEvent(new PointerEvent("pointerup",a)),n.dispatchEvent(new MouseEvent("mouseup",a)),n.dispatchEvent(new MouseEvent("click",a));n instanceof HTMLElement&&n.tagName==="BUTTON"&&n.click()}function S(t,e){let{element:n}=p(t);if(n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement)Q(n,e);else if(n instanceof HTMLElement&&n.isContentEditable)n.textContent=e;else throw new u("elemento n\xE3o aceita digita\xE7\xE3o");n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))}function Q(t,e){let n=t instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,"value")?.set;r?r.call(t,e):t.value=e}function $(t,e){let n=t?p(t).element:document.activeElement??document.body,r={key:e,code:e,bubbles:!0,cancelable:!0,composed:!0};n.dispatchEvent(new KeyboardEvent("keydown",r)),n.dispatchEvent(new KeyboardEvent("keypress",r)),n.dispatchEvent(new KeyboardEvent("keyup",r)),e==="Enter"&&n instanceof HTMLInputElement&&n.form&&n.form.requestSubmit?.()}function N(t,e){let{element:n}=p(t);if(!(n instanceof HTMLSelectElement))throw new u("elemento n\xE3o \xE9 um <select>");n.value=e,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))}function H(t){let{element:e}=p(t);e.dispatchEvent(new PointerEvent("pointerover",{bubbles:!0,composed:!0})),e.dispatchEvent(new MouseEvent("mouseover",{bubbles:!0,composed:!0})),e.dispatchEvent(new PointerEvent("pointerenter",{bubbles:!0,composed:!0})),e.dispatchEvent(new MouseEvent("mouseenter",{bubbles:!0,composed:!0}))}function I(t,e){if(!t){e==="top"?window.scrollTo({top:0}):e==="center"?window.scrollTo({top:document.body.scrollHeight/2}):window.scrollTo({top:document.body.scrollHeight});return}let{element:n}=p(t);n.scrollIntoView({block:e==="top"?"start":e==="center"?"center":"end"})}function P(t,e){let{element:n}=p(t);throw!(n instanceof HTMLInputElement)||n.type!=="file"?new u("elemento n\xE3o \xE9 um input de arquivo"):new u(`envio de arquivo precisa do modo avan\xE7ado (chrome.debugger); arquivos: ${e.join(", ")}`)}function L(t){return new Promise(e=>setTimeout(e,t))}async function q(t,e="visible",n=3e4){let r=Date.now()+n;for(;Date.now()<r;){let o;try{o=p(t,{requireMatch:!1}).element}catch{o=void 0}if(o){let i=T(o);if(e==="attached"||e==="visible"&&i||e==="hidden"&&!i)return}await L(100)}throw new u(`elemento n\xE3o ficou "${e}" em ${n}ms`)}function O(t,e,n){if(n){let i=Array.from(document.querySelectorAll(t.selectors[0]??"")).map(c=>A(c,e));return{value:i,count:i.length}}let{element:r}=p(t);return{value:A(r,e),count:1}}function A(t,e){switch(e){case"html":return t.innerHTML;case"href":return t.getAttribute("href");case"value":return t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?t.value:t.getAttribute("value");case"src":return t.getAttribute("src");case"count":return 1;default:return(t.textContent??"").trim()}}function B(t,e,n){if(!t){if(e.kind==="equals"&&String(n[e.value??""]??"")!=="")throw new u(`verifica\xE7\xE3o falhou: esperado "${e.value}"`);return}let r=(()=>{try{return p(t,{requireMatch:!1}).element}catch{return}})();switch(e.kind){case"visible":if(!r||!T(r))throw new u("verifica\xE7\xE3o falhou: elemento n\xE3o est\xE1 vis\xEDvel");return;case"hidden":if(r&&T(r))throw new u("verifica\xE7\xE3o falhou: elemento ainda est\xE1 vis\xEDvel");return;case"exists":if(!r)throw new u("verifica\xE7\xE3o falhou: elemento n\xE3o existe");return;case"text":case"equals":{let o=(r?.textContent??"").trim();if(o!==(e.value??""))throw new u(`verifica\xE7\xE3o falhou: "${o}" \u2260 "${e.value??""}"`);return}case"contains":{let o=(r?.textContent??"").trim();if(!o.includes(e.value??""))throw new u(`verifica\xE7\xE3o falhou: "${e.value??""}" n\xE3o encontrado em "${o}"`);return}case"matches":{let o=(r?.textContent??"").trim();if(!new RegExp(e.value??"").test(o))throw new u(`verifica\xE7\xE3o falhou: "${e.value??""}" n\xE3o casa com "${o}"`);return}}}function M(t){try{return new Function(`return (${t})`)()}catch(e){let n=e instanceof Error?e.message:String(e);if(!/Content Security Policy|unsafe-eval/i.test(n))throw e;return G(t)}}function G(t){let e=`griver_eval_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`,n=t.replace(/<\/script/gi,"<\\/script"),r=document.createElement("script");r.textContent=`(function(){
    var out = document.createElement("div");
    out.id = ${JSON.stringify(e)};
    try {
      var value = (function(){ return (${n}) })();
      out.setAttribute("data-value", JSON.stringify(value === undefined ? null : value));
    } catch (error) {
      out.setAttribute("data-error", String(error && error.message ? error.message : error));
    }
    (document.documentElement || document.body).appendChild(out);
  })();`;let o=document.documentElement??document.body;if(!o)throw new u("p\xE1gina sem documento para injetar o script");o.appendChild(r),r.remove();let i=document.getElementById(e);if(!i)throw new u("a p\xE1gina bloqueou a execu\xE7\xE3o de script (CSP) e o passo n\xE3o p\xF4de ser conclu\xEDdo");let c=i.getAttribute("data-error"),a=i.getAttribute("data-value");if(i.remove(),c)throw new u(c);if(a!==null)try{return JSON.parse(a)}catch{return a}}function U(){return location.href}var x=new w,_=new y;chrome.runtime.onMessage.addListener((t,e,n)=>{switch(t.type){case d.recordCommand:{let r=t.command;if(r.action==="start")x.start(o=>{chrome.runtime.sendMessage({type:d.recordEvent,event:o}).catch(()=>{})});else if(r.action==="pause")x.pause();else if(r.action==="resume")x.resume();else if(r.action==="stop"){let o=x.stop();return n({ok:!0,events:o}),!1}return n({ok:!0}),!1}case d.overlayState:return _.render(t.state),!1;case d.execute:{let r=t.command;return ee(r.step).then(o=>n({ok:!0,result:o})).catch(o=>n({ok:!1,error:o instanceof Error?o.message:String(o)})),!0}case d.pageCommand:{let r=t.command;return te(r).then(o=>n({ok:!0,result:o})).catch(o=>n({ok:!1,error:o instanceof Error?o.message:String(o)})),!0}default:return!1}});_.mount().then(t=>{t.recording&&!t.paused&&x.start(e=>{chrome.runtime.sendMessage({type:d.recordEvent,event:e}).catch(()=>{})})});async function ee(t){let e=t.target;switch(t.type){case"click":k(e,{clickCount:t.clickCount??1,force:t.force??!1});return;case"fill":S(e,String(t.value??""));return;case"press":$(t.target?e:void 0,String(t.key??""));return;case"select":N(e,String(t.value??""));return;case"hover":H(e);return;case"scrollTo":I(t.target?e:void 0,t.position);return;case"upload":P(e,t.files??[]);return;case"wait":await L(Number(t.ms??0));return;case"waitFor":await q(e,t.state,Number(t.timeout??3e4));return;case"extract":return O(e,t.attr,t.many===!0);case"assert":B(t.target?e:void 0,t.expect,{});return;case"script":return M(String(t.code??""));case"currentUrl":return U();default:throw new Error(`passo n\xE3o suportado na aba: ${String(t.type)}`)}}async function te(t){switch(t.action){case"context":return ne();case"click":return k(t.payload?.target,t.payload?.options),{ok:!0};case"fill":return S(t.payload?.target,String(t.payload?.value??"")),{ok:!0};case"evaluate":return M(String(t.payload?.code??""));case"screenshot":return{ok:!0};case"navigate":return window.location.href=String(t.payload?.url??""),{ok:!0};default:throw new Error(`comando de p\xE1gina desconhecido: ${t.action}`)}}function ne(){let t=[],e=document.querySelectorAll("a, button, input, textarea, select, [role=button], [onclick], [contenteditable=true]");for(let n of Array.from(e).slice(0,120)){let r=g(n);r.length&&t.push({tag:n.tagName.toLowerCase(),type:n instanceof HTMLInputElement?n.type:void 0,text:E(n,40),value:n instanceof HTMLInputElement&&n.type!=="password"?n.value:void 0,placeholder:n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement?n.placeholder:void 0,selectors:r.map(o=>o.selector)})}return{url:location.href,title:document.title,elements:t}}})();
